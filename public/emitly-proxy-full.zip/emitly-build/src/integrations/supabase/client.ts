import { createClient } from '@supabase/supabase-js';
import type { Database } from './types';

const SUPABASE_URL = "https://emitly.ru/api";
const SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZrZWxpcWplZGJxcWhpdGVob3lzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNjQwODQsImV4cCI6MjA4OTk0MDA4NH0.XIEpV5rIBKLQOPnGLYWVWY3hSp-5INgwmhsjLsOZsyQ";

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: { storage: localStorage, persistSession: true, autoRefreshToken: true },
});
